﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlazorDemoWithAuth.Shared.Models
{
    public class Actor
    {
        public int Id { get; set; }
        public string ActorName { get; set; }
        public string MovieName { get; set; }
    }
}
