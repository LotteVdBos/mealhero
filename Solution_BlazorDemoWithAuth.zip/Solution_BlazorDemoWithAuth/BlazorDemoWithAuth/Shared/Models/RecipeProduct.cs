﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlazorDemoWithAuth.Shared.Models
{
    public class RecipeProduct
    {
        public int ID { get; set; }
        public int campaignID { get; set; }
        public string name { get; set; }
        public string URL { get; set; }
        public string images { get; set; }
        public string description { get; set; }
    }
}
