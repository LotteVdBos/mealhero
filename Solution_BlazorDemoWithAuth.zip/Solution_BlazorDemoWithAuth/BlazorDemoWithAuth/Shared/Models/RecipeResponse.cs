﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlazorDemoWithAuth.Shared.Models
{
    public class RecipeResponse
    {
        public List<RecipeProduct> RecipeProducts { get; set; }
    }
}
