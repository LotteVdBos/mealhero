﻿using BlazorDemoWithAuth.Server.Data;
using BlazorDemoWithAuth.Shared.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlazorDemoWithAuth.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DemoDataController : ControllerBase
    {
        //fields
        private readonly Data.ApplicationDbContext context;
        private readonly IWebHostEnvironment env;
        private StringBuilder sbInfo = new StringBuilder();

        //ctor
        public DemoDataController(ApplicationDbContext context, IWebHostEnvironment env)
        {
            this.context = context;
            this.env = env;
        }

        //Methods
        [Route("/InsertDemoData")]
        public string InsertDemoData()
        {
            //Insert
            InsertCategories();
            InsertActors();
            InsertFoods();

            //return
            sbInfo.AppendLine();
            sbInfo.AppendLine();
            sbInfo.Append("InsertDemoData End !");
            return sbInfo.ToString();
        }

        //Methods
        [Route("/InsertCategories")]
        public void InsertCategories()
        {
            //Controle
            if (context.Categories.Any())
            {
                //Stop maar
                sbInfo.Append($"Categories: {context.Categories.Count()} Records Found !");
                sbInfo.AppendLine();
                return;
            }

            //List Categories
            List<Category> categories = new List<Category>()
            {
                new Category() { CategoryName="Best Actor in a Leading Role" },
                new Category() { CategoryName="Best Actor in a Supporting Role" },
                new Category() { CategoryName="Best Actress in a Leading Role" },
                new Category() { CategoryName="Best Actress in a Supporting Role" },
                new Category() { CategoryName="Best Animated Feature" },
                new Category() { CategoryName="Best Animated Short Film" },
                new Category() { CategoryName="Best Cinematography" },
                new Category() { CategoryName="Best Costume Design" },
                new Category() { CategoryName="Best Director" },
                new Category() { CategoryName="Best Documentary Feature" },
                new Category() { CategoryName="Best Documentary Short" },
                new Category() { CategoryName="Best Film Editing" },
                new Category() { CategoryName="Best Foreign Language Film" },
                new Category() { CategoryName="Best Live Action Short Film" },
                new Category() { CategoryName="Best Makeup and Hairstyling" },
                new Category() { CategoryName="Best Original Score" },
                new Category() { CategoryName="Best Original Song" },
                new Category() { CategoryName="Best Picture" },
                new Category() { CategoryName="Best Production Design" },
                new Category() { CategoryName="Best Sound Editing" },
                new Category() { CategoryName="Best Sound Mixing" },
                new Category() { CategoryName="Best Visual Effects" },
                new Category() { CategoryName="Best Adapted Screenplay" },
                new Category() { CategoryName="Best Original Screenplay" }
            };

            //Add
            context.Categories.AddRange(categories);
            context.SaveChanges();

            //return
            sbInfo.Append($"Categories: {context.Categories.Count()} Records Inserted !");
            sbInfo.AppendLine();
            return;

        }
        
        //Methods
        [Route("/InsertActors")]
        public void InsertActors()
        {
            //Controle
            if (context.Actors.Any())
            {
                //Stop maar
                sbInfo.Append($"Actors: {context.Actors.Count()} Records Found !");
                sbInfo.AppendLine();
                return;
            }

            //List Categories
            List<Actor> actors = new List<Actor>()
            {
          new Actor() { ActorName = "Frances McDormand", MovieName = " Nomadland " },
        new Actor() { ActorName = "Viola Davis", MovieName = " Ma Rainey's Black Bottom " },
        new Actor() { ActorName = "Andra Day", MovieName = " The United States vs. Billie Holiday " },
        new Actor() { ActorName = "Vanessa Kirby", MovieName = " Pieces of a Woman " },
        new Actor() { ActorName = "Carey Mulligan", MovieName = " Promising Young Woman " },

            };

            //Add
            context.Actors.AddRange(actors);
            context.SaveChanges();

            //return
            sbInfo.Append($"Actors: {context.Actors.Count()} Records Inserted !");
            sbInfo.AppendLine();
            return;

        }

        //Methods
        [Route("/InsertFoods")]
        public void InsertFoods()
        {
            //Controle
            if (context.Foods.Any())
            {
                //Stop maar
                sbInfo.Append($"Foods: {context.Foods.Count()} Records Found !");
                sbInfo.AppendLine();
                return;
            }

            //List Categories
            List<Food> foods = new List<Food>()
            {
          new Food() {  FoodName= "Homemade Granola", Calorie = 489 },
          new Food() {  FoodName= "Meats (Chicken Leg)", Calorie = 184 },
          new Food() {  FoodName= "Firm Tofu", Calorie = 144 },
          new Food() {  FoodName= "Fish (Salmon)", Calorie = 206 },
          new Food() {  FoodName= "Avocados", Calorie = 160 },
          new Food() {  FoodName= "Dairy Foods (Milk)", Calorie = 61 },
          new Food() {  FoodName= "Chickpeas", Calorie = 164 },
          new Food() {  FoodName= "Sweet Potatoes", Calorie = 101 },
          new Food() {  FoodName= "Whole Grains (Brown Rice)", Calorie = 123 },
          new Food() {  FoodName= "Nuts (Macadamia Nuts)", Calorie = 718 },            };

            //Add
            context.Foods.AddRange(foods);
            context.SaveChanges();

            //return
            sbInfo.Append($"Foods: {context.Foods.Count()} Records Inserted !");
            sbInfo.AppendLine();
            return;

        }
    }
}
